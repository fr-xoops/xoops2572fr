<?php
/**
 * PHPMailer language file.
 * English Version
 */

$PHPMAILER_LANG['provide_address'] = 'Vous devez fournir au moins une adresse électronique du destinataire.';
$PHPMAILER_LANG['mailer_not_supported'] = 'programme de courrier non pris en charge.';
$PHPMAILER_LANG['execute'] = 'Impossible d\'exécuter :';
$PHPMAILER_LANG['instantiate'] = 'Impossible d\'instancier la fonction de courrier électronique.';
$PHPMAILER_LANG['authenticate'] = 'Erreur SMTP : Impossible de s\'authentifier.';
$PHPMAILER_LANG['from_failed'] = 'L\'envoi de l\'expéditeur a échoué  :';
$PHPMAILER_LANG['recipients_failed'] = 'Erreur SMTP : Les destinataires suivants ont échoué :';
$PHPMAILER_LANG['data_not_accepted'] = 'Erreur SMTP : Données non acceptées.';
$PHPMAILER_LANG['connect_host'] = 'Erreur SMTP : Impossible de se connecter à l\'hôte SMTP.';
$PHPMAILER_LANG['file_access'] = 'Impossible d\'accéder au fichier :';
$PHPMAILER_LANG['file_open'] = 'Erreur de fichier : Impossible d\'ouvrir le fichier :';
$PHPMAILER_LANG['encoding'] = 'Codage inconnu :';
$PHPMAILER_LANG['signing'] = 'Erreur de signature :';
$PHPMAILER_LANG['smtp_error'] = 'Erreur de serveur SMTP :';
$PHPMAILER_LANG['empty_message'] = 'Corps du message vide';
$PHPMAILER_LANG['invalid_address'] = 'Adresse incorrecte';
$PHPMAILER_LANG['variable_set'] = 'Impossible de définir ou réinitialiser la variable :';
